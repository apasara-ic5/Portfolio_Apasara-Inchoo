package com.example.healthcheck_034;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button count,commend;
    EditText rewe,rehe;
    TextView sh;
    double num = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        count=findViewById(R.id.calculate);
        rewe=findViewById(R.id.weightreply);
        rehe=findViewById(R.id.heightreply);
        commend=findViewById(R.id.recoome);
        sh = findViewById(R.id.answer);



        count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double n1 = Double.parseDouble(rewe.getText().toString());
                double n2 = Double.parseDouble(rehe.getText().toString());
                n2=n2/100;
                num= n1/(n2*n2);

                sh.setText("BMI = "+String.format("%.2f",num) );



            }
        });
        commend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent va = new Intent(MainActivity.this,recom.class);
                va.putExtra("Calcu",num);
                startActivity(va);
            }
        });


    }
}